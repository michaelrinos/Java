/**
 * $Id: WheelConfig.java,v 1.5 2014/10/29 02:36:01 mer8503 Exp $
 * 
 * $Log: WheelConfig.java,v $
 * Revision 1.5  2014/10/29 02:36:01  mer8503
 * *** empty log message ***
 *
 * Revision 1.4  2014/10/29 02:04:21  mer8503
 * *** empty log message ***
 *
 * Revision 1.3  2014/10/29 02:02:32  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/10/29 00:19:57  mer8503
 * *** empty log message ***
 *
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Scanner;


/**
 * @author Michael Rinos mer8503
 */

public class WheelConfig implements Configuration {
	
	int numTriads, count;
	File file;
	Integer[] Triad;
	private int totalVal;
	ArrayList<Integer> bVals = new ArrayList<Integer>();
	ArrayList<Integer> nums = new ArrayList<Integer>();

	/**
	 * Constructs an initial number wheel puzzle from an input file whose format is: #_triads bridge1_value bridge2_value...A
	 * @param filename string containing file to run
	 * @throws FileNotFoundException if file not found this is thrown
	 */
	public WheelConfig(String filename) throws FileNotFoundException{
		file = new File(filename);
		Scanner in = new Scanner(file);
		this.numTriads = in.nextInt();
		in.nextLine();
		String[] split = in.nextLine().split(" ");	
		for(int i=1; i<=numTriads; i++){
			bVals.add(Integer.parseInt(split[i-1]));
			//System.out.println(bVals.get(i-1));
		}				
		for(int j=1; j<=(numTriads*3); j++){
			nums.add(j);
		}
		this.Triad = new Integer[numTriads*3];	
		for(int i=0; i< Triad.length; i++){
			if(Triad[i]==null){
				Triad[i]=0;
			}
		}

		for(int p:nums){
			totalVal+=p;
		}
		this.totalVal=this.totalVal/numTriads;
		in.close();
	}

	/**
	 * Copy constructor. Takes an incoming config and makes a complete deep copy of its attributes.
	 * @param config An instance of a wheelconfig to copy
	 */
	public WheelConfig(WheelConfig config){
		this.numTriads = config.numTriads;
		this.bVals = new ArrayList<Integer>(config.bVals);
		this.nums = new ArrayList<Integer>(config.nums);
		this.Triad = new Integer[numTriads*3];
		this.totalVal=config.totalVal;
		System.arraycopy(config.Triad, 0, this.Triad, 0, (numTriads*3));

	}


	/**
	 * Get the collection of successors from the current one.
	 * 
	 */
	@Override
	public Collection<Configuration> getSuccessors() {
		ArrayList<Integer> tnums = new ArrayList<Integer>(nums);
		Collection<Configuration> successors = new LinkedList<Configuration>();
		boolean check = true;
		int flag = 0;
		while(check){
			if(flag >= numTriads*3){
				check=false;
				return successors;
			}
			if(Triad[flag]==0){
				check = false;
				count = flag;
			}
			flag++;
		}

		for(int i : Triad){
			for(int j=0; j<tnums.size(); j++){
				if(i==tnums.get(j)){
					tnums.remove(j);
				}
			}
		}
		for(int y:tnums){
			WheelConfig c = new WheelConfig(this);
			c.Triad[count]=y;

			successors.add(c);

		}	

		return successors;//collection;
	}

	/**
	 * Is the current configuration valid or not?
	 */
	@Override
	public boolean isValid() {
		ArrayList<Integer> bcopy = new ArrayList<Integer>(bVals);
		int tempTotal;

		ArrayList<Integer> seen=new ArrayList<Integer>();


		//check bridge
		
		for (int i = 1; i<numTriads;i++){
			if(Triad[(3*i)-1]!=0 && (Triad[3*i]!=0)){
				if (bcopy.get(i-1)==Triad[(3*i)-1]+Triad[3*i]){
				}
				else {
					return false;
				}
			}
		}
		for(int i=1; i<= numTriads; i++){//full and ==15
			if(Triad[(3*i)-3]!=0 &&
					Triad[(3*i)-2]!=0 &&
					Triad[(3*i)-1]!=0){
				tempTotal=Triad[(3*i)-3]+Triad[(3*i)-2]+Triad[(3*i)-1];
				if(tempTotal==totalVal){}
				else{
					return false;
				}	

			}
		}

		for(int i=0; i<numTriads*3; i++){ //   check if duplicate numbers
			if(seen.contains(Triad[i])){
				return false;
			}
			else{
				if(Triad[i]!=0){
					seen.add(Triad[i]);	
				}

			}
		}
		

		return true;



	}
	/**
	 * Is the current configuration a goal?
	 */
	@Override
	public boolean isGoal() {
		int tempTotal;
		int totalVal=0;
		ArrayList<Integer> bcopy = new ArrayList<Integer>(bVals);
		for(int p:nums){
			totalVal+=p;
		}
		totalVal=totalVal/numTriads;
		
		
		for(int i=0; i<numTriads; i++){ //   check if total triad value is greater then allowed triad total value
			tempTotal=0;

			for(int x=0; x<3; x++){
				if(Triad[((i*3)+x)]==0){
					tempTotal+=0;
				}
				else{
					tempTotal+=Triad[((i*3)+x)];
				}
			}
			if(tempTotal==totalVal){}
			else{
				return false;
			}	
		}
		//check bVals

		for (int i = 1; i<numTriads;i++){
			if(Triad[(3*i)-1]!=0 && (Triad[3*i]!=0)){
				if (bcopy.get(i-1)==Triad[(3*i)-1]+Triad[3*i]){
				}
				else {
					return false;
				}
			}
		}
		if (bcopy.get(bcopy.size()-1)==Triad[0]+Triad[Triad.length-1]){
			
		}
		else {
			return false;
		}
		return true;
	}
	/**
	 * toString in class java.lang.Object
	 */
	public String toString(){
		String s="";
		int c=0;
		System.out.println(bVals);
		for(int x=1; x<=numTriads; x++){
			for(int y=0; y<3; y++){
				s=s+Triad[c];
				if(y<2){
					s=s+".";
				}
				c++;
			}
			if(x<(numTriads)){
				s=s+" - ";
			}
		}
		return s;
	}
}