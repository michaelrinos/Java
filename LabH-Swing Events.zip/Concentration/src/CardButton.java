/**
 * /**
 * CardButton.java
 *
 * File:
 *	$Id: CardButton.java,v 1.1 2014/11/10 22:41:24 mer8503 Exp $
 *
 * Revisions:
 *	$Log: CardButton.java,v $
 *	Revision 1.1  2014/11/10 22:41:24  mer8503
 *	*** empty log message ***
 *
 */
import javax.swing.JButton;
/**
 * 
 * @author Michael Rinos mer8503
 *
 */

public class CardButton extends JButton {
	
	int pos;
	
	CardButton(int pos){
		this.pos=pos;
	}
	
	public int getPos(){
		return this.pos;
	}
	
}
