/**
 * CheatFrame.java
 *
 * File:
 *	$Id: CheatFrame.java,v 1.1 2014/11/10 22:41:24 mer8503 Exp $
 *
 * Revisions:
 *	$Log: CheatFrame.java,v $
 *	Revision 1.1  2014/11/10 22:41:24  mer8503
 *	*** empty log message ***
 *
 */

import java.awt.Color;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * 
 * @author Michael
 *
 */



public class CheatFrame extends JFrame implements Observer{
	Color[] allColors = {Color.DARK_GRAY,Color.BLUE,Color.GREEN,Color.CYAN,
			Color.RED, Color.MAGENTA,Color.ORANGE,Color.GRAY};
	ConcentrationModel model;
	int size;
	ArrayList<CardButton> cardButtons;
	JPanel cardPanel;
	
	public CheatFrame(ArrayList<CardButton> cardButtons,int size, ConcentrationModel model){
		this.model=model;
		model.addObserver(this);
		this.size=size;
		this.cardButtons=cardButtons;
		cardPanel=new JPanel();
		cardPanel.setLayout(new GridLayout(4,4));
		this.add(cardPanel);
		
		
		setTitle("Cheat Frame");
		setSize(375,375);
		this.setLocation(515, 100);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		populate(model);
	}

	

	@Override
	public void update(Observable arg0, Object arg1) {
		ConcentrationModel m=(ConcentrationModel)arg0;
		ArrayList<CardFace> cardFaces = m.cheat();
		for (int i =0 ; i < cardButtons.size();i++){
			cardPanel.getComponent(i);
			((JLabel)cardPanel.getComponent(i)).setText(""+cardFaces.get(i));
			cardPanel.getComponent(i).setBackground(allColors[cardFaces.get(i).getNumber()]);
		}
	}
	
	private void populate(ConcentrationModel m){
		ArrayList<CardFace> cardFaces = m.cheat();
		for (int i = 0; i< this.cardButtons.size();i++ ){
			CardFace cardFace = cardFaces.get(i);
			JLabel label = new JLabel("",SwingConstants.CENTER);
			label.setText(""+cardFaces.get(i));
			label.setOpaque(true);
			label.setForeground(Color.BLACK);
			label.setBackground(allColors[cardFaces.get(i).getNumber()]);
			cardPanel.add(label);
		}
	}
}
