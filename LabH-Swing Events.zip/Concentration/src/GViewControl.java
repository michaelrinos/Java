/**
 * GViewControl.java
 *
 * File:
 *	$Id: GViewControl.java,v 1.1 2014/11/10 22:41:24 mer8503 Exp $
 *
 * Revisions:
 *	$Log: GViewControl.java,v $
 *	Revision 1.1  2014/11/10 22:41:24  mer8503
 *	*** empty log message ***
 *
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

/**
 * 
 * @author Michael Rinos mer8503
 *
 */
public class GViewControl extends JFrame implements Observer {
	private ConcentrationModel model;
	private ArrayList<CardButton> allButtons;
	private JLabel movelabel;
	Color[] allColors = {Color.DARK_GRAY,Color.BLUE,Color.GREEN,Color.CYAN,
			Color.RED, Color.MAGENTA,Color.ORANGE,Color.GRAY};
	
	
	public GViewControl(ConcentrationModel model){
		
		setUIFont (new javax.swing.plaf.FontUIResource("Serif",Font.BOLD,24));
		this.model=model;
		model.addObserver(this);
		allButtons=new ArrayList<CardButton>();
		
		JPanel cardPanel = new JPanel();
		cardPanel.setLayout(new GridLayout(4,4,2,2));
		JPanel northFlow= new JPanel();
		JPanel southFlow= new JPanel();
		northFlow.setLayout(new FlowLayout(FlowLayout.LEFT));
		southFlow.setLayout(new FlowLayout(FlowLayout.RIGHT));
		
		this.movelabel= new JLabel("Moves: 0 Select the first card.");
		northFlow.add(movelabel);
		JButton reset = new JButton("Reset"); 
		JButton cheat = new JButton("Cheat");
		JButton undo  = new JButton("Undo");
		southFlow.add(reset);
		southFlow.add(cheat);
		southFlow.add(undo);
		
		reset.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent event){
				getModel().reset();
				
				

			}
		});
		cheat.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent event){
				CheatFrame frame = new CheatFrame(allButtons,allButtons.size(),getModel());
				getModel().cheat();
				
				
				
			}
		});
		undo.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent event){
				getModel().undo();
			}
		});
		
		for (int cardNumber = 0; cardNumber<16;cardNumber++){
			CardButton cardButton = new CardButton(cardNumber);
			cardButton.setForeground(Color.WHITE);
			cardButton.setBackground(Color.BLACK);
			cardPanel.add(cardButton);
			cardButton.setBorderPainted(true);
			cardButton.setContentAreaFilled(false);
			cardButton.setOpaque(true);
			allButtons.add(cardButton);
			
			cardButton.addActionListener(new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent event){
					getModel().selectCard((((CardButton) event.getSource()).getPos()));
				}
			});
		}
		this.add(cardPanel,BorderLayout.CENTER);
		this.add(northFlow,BorderLayout.NORTH);
		this.add(southFlow,BorderLayout.SOUTH);
		
		setTitle("Concentration Game");
		setSize(500,500);
		this.setLocation(100, 100);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		update(model,this);
		
	}
	
	public static void setUIFont (javax.swing.plaf.FontUIResource f){
	    java.util.Enumeration keys = UIManager.getDefaults().keys();
	    while (keys.hasMoreElements()) {
	      Object key = keys.nextElement();
	      Object value = UIManager.get (key);
	      if (value != null && value instanceof javax.swing.plaf.FontUIResource)
	        UIManager.put (key, f);
	      }
	    } 
	
	public ConcentrationModel getModel() {
		return model;
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		String numMoves = ""+model.getMoveCount();
		int numCardsup = model.howManyCardsUp();
		if(numCardsup==0){
			movelabel.setText("Moves: "+numMoves+"Select the first card");
		}
		else if (numCardsup==1){
			movelabel.setText("Moves: "+numMoves+"Select the secound card");
		}
		else{
			movelabel.setText("Moves: "+numMoves+"Select the first card");
		}
		ArrayList<CardFace> cardFaces = model.getCards();
		for (int index=0;index<16;index++){
			CardButton currentCard= allButtons.get(index);
			CardFace cardFace = cardFaces.get(index);
			if (cardFace.isFaceUp()){
				currentCard.setText(""+cardFace.getNumber());
				currentCard.setBackground(allColors[cardFace.getNumber()]);
			}
			else{
				currentCard.setText("");
				currentCard.setBackground(null);
			}
			
		}
	}
	
	public static void main(String[] args){
		GViewControl game= new GViewControl(new ConcentrationModel());
		
	}
}
