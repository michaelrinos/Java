/**
 * PrimeSieve.java
 * 
 * Version:
 *		$Id: PrimeSieve.java,v 1.5 2014/09/02 04:22:15 mer8503 Exp $
 *
 * Revisions:
 * 		$Log: PrimeSieve.java,v $
 * 		Revision 1.5  2014/09/02 04:22:15  mer8503
 * 		*** empty log message ***
 *
 * 		Revision 1.4  2014/08/30 20:17:55  mer8503
 * 		Finding the bug that led to the incompletion of the prime number list-fixed
 *
 * 		Revision 1.3  2014/08/30 14:19:48  mer8503
 * 		gg
 *
 * 		Revision 1.2  2014/08/30 14:19:15  mer8503
 * 		*** empty log message ***
 *
 * 		Revision 1.1  2014/08/29 23:35:20  mer8503
 * 		PrimeFinder ( first lab)
 *
 */

import java.util.ArrayList;
import java.util.Scanner;

/**
 * A class that computes prime numbers between 2 and N, using the Sieve of 
 * Eratosthenes algorithm.
 * <P>
 * Example 1: 
 * On the second line, the program waits after the colon character 
 * for the user to enter the maximum number, N, and 
 * the user enters 72 as the value for 'N'.
 * <PRE>
 * $ java PrimeSieve
 * Compute prime numbers from 2 to: 72
 * Prime numbers: 2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71
 * $ 
 * </PRE>
 * <P>
 * Example 2: The user enters 1, an invalid value for 'N', and
 * the program displays the following message instead of running the algorithm:
 * <PRE>
 * $ java PrimeSieve
 * Compute prime numbers from 2 to: 1
 * N must be greater than or equal to 2.
 * </PRE>
 *  
 * @author sps Sean Strout
 * @author mer8503 Michael Rinos
 */
public class PrimeSieve {

    /**
     * Find and return the prime numbers between 2 and N inclusive.
     * this is a change
     * @param N The maximum value (inclusive) to check.
     * @return A list of prime numbers
     */
    public static ArrayList<Integer> findPrimes(int N) {
        // the discovered prime numbers go here
        ArrayList<Integer> primes = new ArrayList<Integer>();
        
        ArrayList<Integer> candidate = new ArrayList<Integer>();
        

        // create a candidate list of values 2..N
        for (int i=2; i<=N; i++){
        	candidate.add(i);
        }
        while(candidate.size()>0){
        	ArrayList<Integer> survivor = new ArrayList<Integer>();
        	primes.add(candidate.get(0));
        	for (int i =0;i<candidate.size();i++){
        		if (candidate.get(i)%primes.get(primes.size()-1)!=0)
        			survivor.add(candidate.get(i));
        	}
        candidate=survivor;
        
        }
        return primes;
    
        
        
        

        // loop through candidate values until none remain
		
            // the first candidate is always a prime


            // sieve the remaining candidates that are not evenly divisible by
            // the current prime.  Note:  Java will generate a concurrent
            // modification exception if you attempt to foreach and remove
            // over the candidate list.



           // findPrimes()
    }
    /**
     * The main method.
     * 
     * @param args The command line arguments (unused)
     */
    public static void main(String[] args) {
		
        // read input value, N
        System.out.print("Compute prime numbers from 2 to: ");
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
		in.close();
        if (N < 2) {
            System.out.println("N must be greater than or equal to 2.");
        } else {
            ArrayList<Integer> primes = findPrimes(N);

            // display output
            System.out.print("Prime numbers: ");
            for (Integer i : primes) {
                System.out.print(i + " ");
            }
        }
    }   // main()
}   // PrimeSieve{}
