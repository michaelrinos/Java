/**
 * Version:
 *		$Id: PizzaRun.java,v 1.6 2014/09/03 02:46:02 mer8503 Exp $
 *
 *Revisions:
 * 		$Log: PizzaRun.java,v $
 * 		Revision 1.6  2014/09/03 02:46:02  mer8503
 * 		*** empty log message ***
 *
 * 		Revision 1.5  2014/09/03 02:42:23  mer8503
 * 		*** empty log message ***
 */


/**
 * @author mer8503 Michael Rinos 
 *
 */
public class PizzaRun {
	/**
	 * Processes command line arguments 
	 * @param args contains the pizza price and number of 
	 * slices per person
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int s=0;
		int length=args.length;
		for (int i=1;i<length;i++){
			s+=Double.parseDouble(args[i]);
		}
		double pies = calcWholePies(s);		
		double price = Double.parseDouble(args[0])*pies;
		double extra = pies*SLICE_PER_PIE-s;
		
		System.out.println("Buy "+pies+" pies for $"+price);
		System.out.println("There will be "+extra+" extra slices");
		
	}
	/**
	 * Slices per each pizza pie
	 */
	public static final int SLICE_PER_PIE=8;
	
	/**
	 * Calculates pies needed based on total slices per person
	 * @param nSlices the number of total slices for everyone
	 * @return the number of pies required to 
	 * fulfill everyones pizza desires
	 */
	public static int calcWholePies(int nSlices){
		return (nSlices/SLICE_PER_PIE)+1;
	}
}
