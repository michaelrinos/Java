/**
 * Snowflake.java
 * 
 * Version:
 *		$Id: Snowflake.java,v 1.7 2014/09/03 02:46:35 mer8503 Exp $:
 * 
 * Revisions:
 * 		$Log: Snowflake.java,v $
 * 		Revision 1.7  2014/09/03 02:46:35  mer8503
 * 		*** empty log message ***
 *  
 */

import java.util.Scanner;

/**
 * @author mer8503 Michael E. Rinos
 *
 */

public class Snowflake {

	/**
	 * main method processes command line arguments and 
	 * executes the program
	 * @param args unused
	 * 
	 */
	public static void main(String[] args) { 
		
		// TODO Auto-generated method stub
		System.out.println("Please input the segment length: ");
		Scanner in = new Scanner(System.in);
		int s=in.nextInt();
		System.out.println("Please input the recursion depth: ");
		int n=in.nextInt();
		in.close();
		Turtle t=init(s);
		snowflake(s,n,t);
		
	}
	/**
	 * Initializes the turtle window and sets its location in
	 * the center
	 * @param S The length of the turtle line segments
	 * @return a Turtle instance to be used by other functions
	 */
	public static Turtle init(int S){
		Turtle T = new Turtle(250,250,0);
		T.setWorldCoordinates(0,0,500,500);
		return T;
	}
	/**
	 * Draws a snow flake for every recursive depth
	 * @param S Size of the turtle line segments
	 * @param N The depth recursion of how many snow flakes to
	 * draw
	 * @param t the instance of the turtle
	 */
	public static void snowflakeSide(int S,int N, Turtle t){
		if (N > 0){ 
			t.goForward(S);
			if (N>1){ //generate the 5 sub-branches of this snowflake part
				t.turnLeft(120);
				for (int i=0;i<5;i++){
					snowflakeSide(S/3,N-1,t);
					t.turnRight(60);	
				}
				t.turnRight(180);	
			}
		t.goForward(-S);
		}
	}
	/**
	 * Draws the basic image of the snow flake 
	 * S Size of the turtle line segments
	 * @param N The depth recursion of how many snow flakes to
	 * draw
	 * @param t the instance of the turtle
	 */
	public static void snowflake(int S,int N, Turtle t){
		for (int i=0;i<6;i++){
			snowflakeSide(S,N,t);
			t.turnLeft(60);
		}
	}
}