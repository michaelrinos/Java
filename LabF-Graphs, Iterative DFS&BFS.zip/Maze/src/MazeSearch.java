/*
 * RoutingIter.java
 *
 * Version:
 * $Id: MazeSearch.java,v 1.3 2014/10/22 00:48:22 mer8503 Exp $
 *
 * Revisions:
 * $Log: MazeSearch.java,v $
 * Revision 1.3  2014/10/22 00:48:22  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/10/16 15:54:27  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/02/06 16:14:18  atd
 * Initial revision using stacks and queues for DFS and BFS.
 *
 */

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

/**
 * Routing class is simulation engine for building and searching a graph
 * using stack-based DFS and queue-based BFS.
 * 
 * @author atd Aaron T Deever
 *@author Michael Rinos mer8503
 */
public class MazeSearch {

	/*
	 * The two types of graph searching we will use
	 */
	public enum SearchType {
		DFS,
		BFS
	}

	/**
	 * Main driver prompts for the name of a graph file, builds the graph,
	 * prompts for a start and finish node name, and prints a resulting path.
	 * 
	 * @param args not used
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter graph data filename: ");
		String filename = in.next();
		Maze g = new Maze(filename);
		//prints the graph
		System.out.print(g);

		// performs either DFS (stack) or BFS (queue) on the graph
		while(true) { 
			// prompt for name of start and finish nodes
			System.out.print("Enter starting node name: ");
			String start = in.next();
			if(!g.isInGraph(start)) { 
				System.out.println(start + " is not a valid node in the graph.");
				continue;
			}

			System.out.print("Enter finishing node name: ");
			String finish = in.next();
			if(!g.isInGraph(finish)) { 
				System.out.println(finish + " is not a valid node in the graph.");
				continue;
			}

			System.out.println("Checking for path existence...");
			boolean found = g.canReachDFS(start, finish);
			if (found) {
				System.out.println("A path exists between " + start + " and " +
						finish + "!");
			} else {
				System.out.println("NO PATH exists between " + start + " and " +
						finish + "!");
			}

			if (found) {
				List<Node> path = null;
				List<Node> sPath = null;
				path = g.searchDFS(start,  finish);
				sPath = g.searchBFS(start, finish);
				
				if(path.size() == 1) { 
					System.out.println("You are already there!");
				}
				else { 
					System.out.println("Any Path: "+ path.size() + " hops:");
					for(int n=0; n < path.size()-1; n++) { 
						System.out.println(path.get(n).getName() + " to " + 
								path.get(n+1).getName());
					}
					System.out.println("Shortest Path: "+sPath.size()+" hops");
					for (int i=0;i<sPath.size()-1;i++){
						System.out.println(sPath.get(i).getName()+ " to "+
								sPath.get(i+1).getName());
					}
					in.close();
					return;
				}
			}
		}
	}
}