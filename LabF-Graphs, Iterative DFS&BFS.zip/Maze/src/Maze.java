/*
 * Graph.java

 *
 * Version:
 * $Id: Maze.java,v 1.3 2014/10/22 00:48:22 mer8503 Exp $
 *
 * Revisions:
 * $Log: Maze.java,v $
 * Revision 1.3  2014/10/22 00:48:22  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/10/16 15:54:25  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/02/06 16:14:18  atd
 * Initial revision using stacks and queues for DFS and BFS.
 *
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;

/**
 * Graph class.  Holds representation of a graph as well as functions to 
 * interact with the graph.
 * 
 * @author atd Aaron T Deever
 * @author sps Sean Strout
 * @author Michael Rinos mer8503
 *
 */
public class Maze {

	/*
	 * graph is represented using a map (dictionary).
	 */
	private Map<String, Node> graph;

	/**
	 * Constructor.  Loads graph from a given filename.  Assumes that each line
	 * in the input file contains the names of two nodes.  Creates nodes
	 * as necessary as well as undirected edges between the nodes.
	 * Returns the graph in the form of a map having the names of the
	 * nodes as keys, and the nodes themselves as values.
	 * 
	 * @param filename name of the input graph specification file
	 */
	public Maze(String filename) throws FileNotFoundException { 

		// open the file for scanning
		File file = new File(filename);
		Scanner in = new Scanner(file);
		// create the graph
		graph = new HashMap<String, Node>();
		if(in.hasNextLine()){
			String line = in.nextLine();
			String[] fields = line.split(" ");
			int row=0;
			int col=0;
			int nodeNeeded=0;
			if (fields.length==2){
				row = Integer.parseInt(fields[0]);
				col = Integer.parseInt(fields[1]);
				nodeNeeded= row*col;
			}

			
			int count =0;
			for (int r=0;r<nodeNeeded;r++){
				String name="";
				name+=Integer.toString(count)+","+Integer.toString(r%col);
				//System.out.println(name);
				int loc=((nodeNeeded-r)%col)*(col*(count+1));

				if (r==(loc-1)&&r!=0){
					count++;
				}
				graph.put(name, new Node(name));
			}


			int counter =0;
			for (int r=0 ; r<row; r++){				
				if (in.hasNextLine()){

					String fLine = in.nextLine();
					String[] fFields=fLine.split("O ");

					for (int i=0;i<fFields.length;i++){
						if (fFields[i].contains(".")){
							String fNode=Integer.toString(counter)+","+Integer.toString(i-1);
							String sNode=Integer.toString(counter)+","+Integer.toString(i);
							graph.get(fNode).addNeighbor(graph.get(sNode));
							graph.get(sNode).addNeighbor(graph.get(fNode));
						}
					}

					if (in.hasNextLine()){
						counter++;
						String sLine=in.nextLine();
						String[] sFields = sLine.split("   ");

						for (int i=0;i<sFields.length;i++){

							if (sFields[i].contains(".")){
								String fNode=Integer.toString(counter-1)+","+Integer.toString(i);
								String sNode=Integer.toString(counter)+","+Integer.toString(i);
								graph.get(fNode).addNeighbor(graph.get(sNode));
								graph.get(sNode).addNeighbor(graph.get(fNode));
							}

						}

					}					
				}
				else{
					System.out.println("OUT OF LINES");
					return;
				}	
			}	
		}
	}

	/**
	 * Method to generate a string associated with the graph.  The string
	 * comprises one line for each node in the graph. Overrides
	 * Object toString method.
	 * 
	 * @return string associated with the graph.
	 */
	public String toString() { 
		String result = "";
		for (String name : graph.keySet()) { 
			result = result + graph.get(name) + "\n";
		}
		return result;
	}

	/**
	 * Method to check if a given String node is in the graph.
	 * @param nodeName: string name of a node
	 * @return boolean true if the graph contains that key; false otherwise
	 */
	public boolean isInGraph(String nodeName) { 
		return graph.containsKey(nodeName);
	}

	/**
	 * For a given start and finish node, we simply want to know whether
	 * a path exists, or not, between them. This is the precursor to 
	 * searchDFS().
	 * @param start the name associated with the node from which to start the search
	 * @param finish the name associated with the destination node	 
	 * @return boolean true if a path exists; false otherwise
	 */
	public boolean canReachDFS(String start, String finish) {
		// assumes input check occurs previously
		Node startNode, finishNode;
		startNode = graph.get(start);
		finishNode = graph.get(finish);

		// prime the stack with the starting node
		Stack<Node> stack = new Stack<Node>();
		stack.push(startNode);

		// create a visited set to prevent cycles
		Set<Node> visited = new HashSet<Node>();
		// add start node to it
		visited.add(startNode);

		// loop until either the finish node is found (path exists), or the 
		// dispenser is empty (no path)
		while (!stack.isEmpty()) { 
			Node current = stack.pop();
			if (current == finishNode) {
				return true;    
			}
			// loop over all neighbors of current
			for (Node nbr : current.getNeighbors()) { 
				// process unvisited neighbors
				if (!visited.contains(nbr)) {
					visited.add(nbr);
					stack.push(nbr);
				}
			}
		}
		return false;
	}

	/**
	 * Method that visits all nodes reachable from the given starting node
	 * in depth-first search fashion using a stack, stopping only if the finishing
	 * node is reached or the search is exhausted.  A predecessors map
	 * keeps track of which nodes have been visited and along what path
	 * they were first reached.
	 * 
	 * @param start the name associated with the node from which to start the search
	 * @param finish the name associated with the destination node
	 * @return path the path from start to finish.  Empty if there is no such path.
	 * 
	 * Precondition: the inputs correspond to nodes in the graph. 
	 */
	public List<Node> searchDFS(String start, String finish) { 

		// assumes input check occurs previously
		Node startNode, finishNode;
		startNode = graph.get(start);
		finishNode = graph.get(finish);

		// prime the dispenser (stack) with the starting node
		List<Node> dispenser = new LinkedList<Node>();
		dispenser.add(0, startNode);

		// construct the predecessors data structure
		Map<Node, Node> predecessors = new HashMap<Node,Node>();
		// put the starting node in, and just assign itself as predecessor
		predecessors.put(startNode, startNode);

		// loop until either the finish node is found, or the 
		// dispenser is empty (no path)
		while (!dispenser.isEmpty()) { 
			Node current = dispenser.remove(0); 
			if (current == finishNode) {
				break;
			}
			// loop over all neighbors of current
			for (Node nbr : current.getNeighbors()) { 
				// process unvisited neighbors
				if(!predecessors.containsKey(nbr)) { 
					predecessors.put(nbr, current);
					dispenser.add(0, nbr);
				}
			}
		}

		return constructPath(predecessors, startNode, finishNode);
	}

	/**
	 * Method that visits all nodes reachable from the given starting node
	 * in breadth-first search fashion using a queue, stopping only if the finishing
	 * node is reached or the search is exhausted.  A predecessors map
	 * keeps track of which nodes have been visited and along what path
	 * they were first reached.
	 * 
	 * @param start the name associated with the node from which to start the search
	 * @param finish the name associated with the destination node
	 * @return path the path from start to finish.  Empty if there is no such path.
	 * 
	 * Precondition: the inputs correspond to nodes in the graph. 
	 */
	public List<Node> searchBFS(String start, String finish) { 

		// assumes input check occurs previously
		Node startNode, finishNode;
		startNode = graph.get(start);
		finishNode = graph.get(finish);

		// prime the dispenser (queue) with the starting node
		List<Node> dispenser = new LinkedList<Node>();
		dispenser.add(startNode);

		// construct the predecessors data structure
		Map<Node, Node> predecessors = new HashMap<Node,Node>();
		// put the starting node in, and just assign itself as predecessor
		predecessors.put(startNode, startNode);

		// loop until either the finish node is found, or the 
		// dispenser is empty (no path)
		while (!dispenser.isEmpty()) { 
			Node current = dispenser.remove(0);
			if (current == finishNode) {
				break;
			}
			// loop over all neighbors of current
			for (Node nbr : current.getNeighbors()) { 
				// process unvisited neighbors
				if(!predecessors.containsKey(nbr)) { 
					predecessors.put(nbr, current);
					dispenser.add(nbr);
				}
			}
		}

		return constructPath(predecessors, startNode, finishNode);
	}


	/**
	 * Method to return a path from the starting to finishing node.
	 * 
	 * @param predecessors Map used to reconstruct the path
	 * @param startNode starting node
	 * @param finishNode finishing node
	 * @return a list containing the sequence of nodes comprising the path.
	 * Empty if no path exists.
	 */
	private List<Node> constructPath(Map<Node,Node> predecessors,
			Node startNode, Node finishNode) { 

		// use predecessors to work backwards from finish to start, 
		// all the while dumping everything into a linked list
		List<Node> path = new LinkedList<Node>();

		if(predecessors.containsKey(finishNode)) { 
			Node currNode = finishNode;
			while (currNode != startNode) { 
				path.add(0, currNode);
				currNode = predecessors.get(currNode);
			}	
			path.add(0, startNode);
		}

		return path;
	}
}