
public class TestCourse {
	public static void main(String[] args) {
		CourseList cl = new CourseList(args[0]);
		System.out.println(cl.getCourse(0));
		Course calc1=cl.getCourse(0);
		System.out.println(cl.getCourse(1));
		Course cs31=cl.getCourse(1);
		
		System.out.println("Does calc.equals(calc)?: "+ calc1.equals(calc1));
		System.out.println("Does calc.equals(cs3)?: "+ calc1.equals(cs31));
		
		System.out.println(calc1.inDay(1));
		
		System.out.println("Is conflict cs3 and calc? : "+ cs31.inConflict(calc1));
		
		Course writting1=cl.getCourse(2);
		Course waterpolo1=cl.getCourse(3);
		
		System.out.println("Is conflict wriiting and wattepolo? : "+ "true? : " + writting1.inConflict(waterpolo1));
		System.out.println("\n");
		System.out.println(cl);
		
		Course calc=cl.getCourse(0);
		Course cs3=cl.getCourse(1);
		Course writting=cl.getCourse(2);
		Course waterpolo=cl.getCourse(3);
		Course discrete=cl.getCourse(4);
		Course mechanics=cl.getCourse(5);
		Course ultimate=cl.getCourse(6);
		Course pickelball=cl.getCourse(7);
		Course tennis=cl.getCourse(8);
		
		System.out.println("Is conflict calc and cs3? : "+ "true? : " + calc.inConflict(cs3));
		System.out.println("Is conflict calc and discrete? : "+ "true? : " + calc.inConflict(discrete));
		System.out.println("Is conflict calc and mechanics? : "+ "true? : " + calc.inConflict(mechanics));
		System.out.println("Is conflict calc and ultimate? : "+ "true? : " + calc.inConflict(ultimate));
		System.out.println("Is conflict calc and pcikelball? : "+ "false? : " + calc.inConflict(pickelball));
		System.out.println("Is conflict calc and tennis? : "+ "true? : " + calc.inConflict(tennis));
		
		
		
		
	}
}
