/**
 * Course.java
 * $Id: Course.java,v 1.7 2014/09/10 01:29:40 mer8503 Exp $:
 * 
 * $Log: Course.java,v $
 * Revision 1.7  2014/09/10 01:29:40  mer8503
 * *** empty log message ***
 *
 * Revision 1.6  2014/09/10 01:13:36  mer8503
 * *** empty log message ***
 *
 * Revision 1.4  2014/09/09 21:25:08  mer8503
 * *** empty log message ***
 *
 * Revision 1.3  2014/09/09 19:26:43  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/09/05 19:15:52  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/03 17:32:41  mer8503
 * Initial Setup
 *:
 */

import java.util.ArrayList;

/**
 * Course object oriented class representing a college course
 * @author mer8503 Michael Rinos
 *
 */

public class Course {

	public static final String dayString=("MTWRF");//not sure why this is needed as its not used but it was in the javadoc
	private String n;//name of course
	private ArrayList<Boolean> days; //array containing bools representing if the course is on that day
	private int start; //start time of the course
	private int end; // end time of the course
	/**
	 * Constructor for a course
	 * @param n - name of the course
	 * @param days - array containing bools representing if the course is on that day
	 * @param start - start time of the course
	 * @param end - end time of the course
	 */
	public Course(String n, ArrayList<Boolean> days,
			int start, int end){
		this.n=n;
		this.days=days;
		this.start=start;
		this.end=end;
	}
	/**
	 * Determines if course 1 == course 2 
	 * @param other - object representing another course
	 * @return boolean representing if the course passed in is equal to the one that called this function
	 */
	public boolean equals(Object other){
		boolean result=false;
		if (other instanceof Course){
			Course v = (Course)other;
			if (this.n == v.n){
				if (this.days == v.days){
					if (this.start == v.start){
						if (this.end == v.end){
							result=true;
						}
					}
				}
			}
		}
	return result; //True if the passed-in Course overlaps in time (on any day) with this Course.
	}
	
	/**
	 * Determines if the course passed in is conflict to the one that called this function
	 * @param other - object representing another course
	 * @return boolean - representing if the course passed in is conflict to the one that called this function
	 */
	public boolean inConflict(Course other){
		if (this.equals(other)){
			return false;
		}
		for (int i =0; i < 5; i++){
			if (this.days.get(0)!=other.days.get(0)){
				if (this.days.get(1)!=other.days.get(1)){
					if (this.days.get(2)!=other.days.get(2)){
						if (this.days.get(3)!=other.days.get(3)){
							if (this.days.get(4)!=other.days.get(4)){
								return false;
							}
						}
					}
				}
			}
		}
		
		if (this.start <= other.start){
			if (this.end > other.start){
				return true;
			}
		}
		if (this.start >= other.start){
			if (this.start<other.end){
				
				return true;
			}
		}
		if (this.start<=other.start){
			if (this.end>other.end){
				return true;
			}
			
		}
		return false;//True if the passed-in Course overlaps in time (on any day) with this Course.
	}
	/**
	 * Creates a string representation of the course, in the form Name: days at start-end (for example: Calculus: MWF at 8-10)
	 * @return String -  representation of the course, in the form Name: days at start-end (for example: Calculus: MWF at 8-10)
	 */
	public String toString(){
		String x="";
		x+=this.n;
		x+=": ";
		for (int i =0; i < this.days.size();i++){
			if (this.days.get(i)==true){
				if (i==0) { x+="M"; }
				if (i==1) { x+="T"; }
				if (i==2) { x+="W"; }
				if (i==3) { x+="R"; }
				if (i==4) { x+="F"; }
			
			}	
		}
		x+=" at " + this.start + " - " + this.end;
		
		return x; //String representation of the course, in the form Name: days at start-end (for example: Calculus: MWF at 8-10) 
	}
	/**
	 * Locates if there are courses on a set day
	 * @param day- int representing the day
	 * @return String- representing the time this course meets on the given day, if any. If it does meet, the String should be in the form Start-end: Name (for example: 8-10: Calculus)
	 */
	public String inDay(int day){
		String x="";
		if (days.get(day)==true){
			x+=Integer.toString(this.start);
			x+=" - ";
			x+=Integer.toString(this.end);
			x+=": ";
			x+=this.n;
		}
		return x; //Returns a string representing the time this course meets on the given day, if any. If it does meet, the String should be in the form Start-end: Name (for example: 8-10: Calculus)
	}
}
