/**
 * Schedule.java
 * $Id: Schedule.java,v 1.3 2014/09/10 01:31:15 mer8503 Exp $:
 * 
 * $Log: Schedule.java,v $
 * Revision 1.3  2014/09/10 01:31:15  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/09/09 21:24:52  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/03 17:32:34  mer8503
 * Initial Setup
 *:
 */

import java.util.ArrayList;

/**
 * Schedule Serves as an object oriented representation of a schedule 
 * @author mer8503 Michael Rinos
 *
 */
public class Schedule {
	private ArrayList<Course> schedules; // arraylist containing courses
	/**
	 * default constructor for a class
	 * sets arraylist schedules to an empty array based list
	 */
	public Schedule(){
		schedules=new ArrayList<Course>();
		
	}
	/**
	 * Tests whether a given Course is currently on the schedule.
	 * @param c- a single course to check for
	 * @return true if the course is on the schedule
	 */
	public boolean contains (Course c){
		boolean result = false;
		for (int i=0; i < schedules.size();i++)
		{
			if (schedules.get(i).equals(c)) result=true;
				
		}
		
		return result; //True if the course is on the schedule.
	}
	/**
	 * Adds the given course to the schedule only if it is not in conflict with courses currently on the schedule.
	 * @param c- Course to attempt to add
	 * @return Whether the course was successfully added
	 */
	public boolean add(Course c){
		if (schedules.size()==0){  
			schedules.add(c);
			return true;
		}
		else {
			for (int i =0; i<schedules.size();i++){
				boolean check=true; 
				check=!schedules.get(i).inConflict(c);
				if (check==false) return false; 
			}
			schedules.add(c);
			return schedules.get(schedules.size()-1).equals(c);
			
			
		}
	}
	/**
	 * simple string representation 
	 * @return String representation of courses
	 */
	public String toString() {
		return "Scheduled with "+ schedules.size() + " courses" + " [schedules=" + schedules + "]";
	}
	/**
	 * prints a day-to-day schedule 
	 */
	public void prettyPrint(){
		String m="----Monday----"+"\n";
		String t="----Tuesday----"+"\n";
		String w="----Wednesday----"+"\n";
		String r="----Thursday----"+"\n";
		String f="----Friday----"+"\n";
		for (int i =0;i<schedules.size();i++){
			
			m+=schedules.get(i).inDay(0);
			t+=schedules.get(i).inDay(1);
			w+=schedules.get(i).inDay(2);
			r+=schedules.get(i).inDay(3);
			f+=schedules.get(i).inDay(4);
			
		}
		System.out.println(m +"\n"+ t +"\n"+ w +"\n"+ r +"\n"+ f);
		
		//Prints a day-by-day schedule (using relevant functions from the Course class), in the following format.
	}
}
