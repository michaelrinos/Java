/**
 * 
 * $Id: $
 * 
 * $Log: $
 * 
 */
import java.util.ArrayDeque;

/**
 * @author Michael Rinos mer8503
 *
 */
public class TrollsBridge {
	int max;
	int curCapacity=0;
	ArrayDeque<Woolie> queue;
	
	/**
	 * Create a TrollsBridge with a given capacity. The municipal authority creates a
	 * TrollsBridge for each bridge that needs management.
	 * @param max - the maximum capacity of the TrollsBridge.
	 */
	public TrollsBridge(int max){
		this.max = max;
		queue  = new ArrayDeque<Woolie>();
	}
	
	/**
	 * Request permission to go onto the troll's bridge.
	 * @param thisWoolie
	 * @return 
	 */
	public synchronized void enterBridgePlease(Woolie thisWoolie){
		
		queue.add(thisWoolie);
		System.out.println(thisWoolie.name + " is starting to cross");
		System.out.println("The troll scowls Get in line! when "+thisWoolie.name+ " shows up at the bridge.");
		while (curCapacity==max || thisWoolie!=queue.peek()){
			try{
				wait();
			}
			catch(InterruptedException ex){
				ex.printStackTrace();
			}
			
			
			
		}
		//Do something critical...
		
		queue.remove();
		curCapacity+=1;
	}
	
	/**
	 * Tell the troll of a TrollsBridge that a woolie has left the bridge so 
	 * that the troll can let other woolies get on if there is room.
	 */
	public synchronized void leave(){
		
		curCapacity -=1;
		notifyAll();
			
		
		
	}
}