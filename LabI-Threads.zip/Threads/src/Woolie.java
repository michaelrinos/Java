/**
 * 
 * $id:$
 * 
 * $Log;$
 * 
 */

/**
 * @author Michael E. Rinos
 *
 */

public class Woolie extends Thread {
	
	int crossTime;
	TrollsBridge guard;
	String name;
	String loc;
	
	
	/**
	 * Construct a new Woolie object that can run as a thread.
	 * @param name - the name of this Woolie
	 * @param crossTime - the number of seconds it takes the Woolie to cross after it has climbed onto the bridge
	 * @param destination - the Woolie's destination city
	 * @param bridgeGuard - the TrollsBridge that the Woolie is crossing
	 */
	public Woolie(String name, int crossTime, String destination, TrollsBridge bridgeGuard){
		this.name = name;
		this.loc = destination;
		this.guard = bridgeGuard;
		this.crossTime = crossTime;
	}
	
	/**
	 * The run method handles a Woolie's behavior as it crosses the bridge.
	 */
	public void run(){
		
		guard.enterBridgePlease(this);
		for (int j=0; j < crossTime;++j){
			System.out.println("\t" +this.name +" "+ j +" secounds");
			try {
				this.sleep(1000);
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(this.name + " leaves at "+ this.loc);
		guard.leave();
	}
}