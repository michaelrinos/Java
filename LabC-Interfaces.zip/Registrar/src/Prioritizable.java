/**
 * 
 * $Id: Prioritizable.java,v 1.3 2014/09/17 03:18:42 mer8503 Exp $
 * 
 * $Log: Prioritizable.java,v $
 * Revision 1.3  2014/09/17 03:18:42  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/09/17 03:17:39  mer8503
 * *** empty log message ***
 *
 * 
 */

/**
 * @author zjb
 * @author mer8503 Michael Rinos
 *
 */
public interface Prioritizable {

	/**
	 * The priority of the object, represented as a number
	 * @return priority 
	 */
	double getPriority();
	
}