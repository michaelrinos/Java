/**
 *
 *$Id: Node.java,v 1.2 2014/09/17 03:18:42 mer8503 Exp $
 *
 * $Log: Node.java,v $
 * Revision 1.2  2014/09/17 03:18:42  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/17 03:17:39  mer8503
 * *** empty log message ***
 *
 * 
 */

/**
 * @author mer8503 Michael Rinos
 * @param <E>
 *
 */
	
public class Node<E> {
	public E data;
	public Node<E> next;
	public Node<E> head;
	public int size;
		
	/**
	 * @param data
	 * @param next
	 * @param prev
	 */
	public Node(E data, Node<E> next){
		this.data=data;
		this.next=next;
	}
	/**
	 * 
	 * @return returns the content in the data slot
	 */
	public E getData() {
		return this.data;
	}

	/**
	 * 
	 * @param data element to reset information in the data slot
	 */
	public void setData(E data) {
		this.data = data;
	}

	/**
	 *  
	 * @return the next element
	 */
	public Node<E> getNext() {
		return next;
	}

	/**
	 * 
	 * @param next changes the next value
	 */
	public void setNext(Node<E> next) {
		this.next = next;
	}
	/**
	 * 
	 * @return the head of the node
	 */
	public Node<E> getHead() {
		return this.head;
	}

	/**
	 * 
	 * @param head element to set the head of the node too
	 */
	public void setHead(Node<E> head) {
		this.head = head;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public int getSize(){
		return this.size;
	}
	public void plusSize(){
		this.size+=1;
	}
	
}
