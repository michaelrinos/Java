import java.util.ArrayList;

/**
 * 
 * $Id: LinkedQueue.java,v 1.2 2014/09/17 03:18:42 mer8503 Exp $
 * 
 * $Log: LinkedQueue.java,v $
 * Revision 1.2  2014/09/17 03:18:42  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/17 03:17:39  mer8503
 * *** empty log message ***
 *
 * 
 */ 

/**
 * @author mer8503 Michael Rinos
 * priority queue using a linked list structure.
 */

public class LinkedQueue<T extends Prioritizable> implements PriorityQueue<T> {
	private Node<T> head;

	public LinkedQueue(){
		this.head=new Node<T>(null,null);
	}

	public boolean isEmpty() {
		boolean result=true;
		if (head.next==null) 
			result=true;
		else result=false;
		return result;
	}
	/**
	 * inserts the element into the correct slot based on the priority
	 * 
	 * @param item to insert
	 * 
	 */
	public void insert(T toInsert) {
		if (isEmpty()==true){
			System.out.println("First");
			head.next=new Node<T>(toInsert,null);
			System.out.println(head.next.data.toString());

		}

		else {
			Node<T> cursor = this.head;
			boolean done=false;
			while (cursor.next!=null&&!done){

				if (cursor.next.data.getPriority()<toInsert.getPriority()){
					Node<T> temp=cursor.next;
					cursor.next=new Node<T>(toInsert,null);
					cursor.next.next=temp;
					done=true;

				}
				cursor=cursor.next;
			}
			if (done==false){
				cursor.next=new Node<T>(toInsert,null);

			}

			Node<T> position = this.head;



		}

	}
	/**
	 * Removes and returns the item at the front of the queue.
	 * @return Removed element
	 */
	public T dequeue() {
		if (this.head.next==null){
			return null;
		}
		else{
			Node<T> cursor=head.next;
			if (cursor.next!=null){
				Node<T> temp=cursor;
				cursor=new Node<T>(null,temp.next);
				this.head=cursor;
				return temp.data;
			}
			else{
				return null;
			}
		}
	}
	public T peak(){
		return this.head.data;
	}
	/**
	 * Tester function to verify the right things are in the queue
	 * @return all the students in the queue 
	 */
	public ArrayList<String> toList() {
		Node<T> position=this.head.next;
		ArrayList<String> x= new ArrayList<String>();
		while(position!=null){
			x.add(position.data.toString());
			position=position.next;
		}
		return x;

	}


}
