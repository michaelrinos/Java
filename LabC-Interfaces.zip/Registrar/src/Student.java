/**
 * $Id: Student.java,v 1.4 2014/09/17 03:18:42 mer8503 Exp $
 * 
 * $Log: Student.java,v $
 * Revision 1.4  2014/09/17 03:18:42  mer8503
 * *** empty log message ***
 *
 * Revision 1.3  2014/09/17 03:17:38  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/09/16 20:54:43  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/16 14:55:55  mer8503
 * *** empty log message ***
 *
 */

/**
 *
 * Student Object oriented class representing a student
 * @author mer8503 Michael Rinos
 *
 */

public class Student implements Prioritizable{
	private String name;
	private double GPA;
	private int year;
	
	public Student(){
		this("Empty",0,0.0);
	}
	
	/**
	 * constructor for the student class
	 * @param name String name of student
	 * @param year int year status of student
	 * @param gpa double gpa of the student
	 */
	
	public Student(String name,int year, double gpa){
		this.name=name;
		this.GPA=gpa;
		this.year=year;
	}
	/**
	 * returns the priority of the student
	 */
	public double getPriority() { return (this.year*10)+this.GPA; }
	/**
	 * 
	 * @return the name of the student
	 */
	public String getName() { return name; }
	/**
	 * 
	 * @param name renames the name of the student
	 */
	public void setName(String name) { this.name = name; }
	
	/**
	 * @return the gpa of the student
	 */
			
	public double getGPA() { return GPA; }
	/**
	 * 
	 * @param gPA sets the gpa to a new gpa
	 */
	public void setGPA(double gPA) { GPA = gPA; }
	/**
	 * 
	 * @return the year of the student
	 */
	public int getYear() { return year; }
	/**
	 * 
	 * @param year resets the year status of the  student
	 */
	public void setYear(int year) { this.year = year; }

	/**
	 * converts a student into something that can be read 
	 */
	public String toString() {
		return "Student [name=" + this.name + ", GPA=" + this.GPA + ", year=" + this.year
				+ "]";
	}
	
	
	
}
