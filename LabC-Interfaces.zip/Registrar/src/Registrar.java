/**
 * 
 * $Id: Registrar.java,v 1.3 2014/09/17 03:23:41 mer8503 Exp $
 * 
 * $Log: Registrar.java,v $
 * Revision 1.3  2014/09/17 03:23:41  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/09/17 03:23:04  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/17 03:22:48  mer8503
 * *** empty log message ***
 *
 * Revision 1.3  2014/09/17 03:17:39  mer8503
 * *** empty log message *** 
 *
 * 
 */

import java.util.Scanner;

/**
 * @author mer8503@g.rit.edu Michael Rinos
 * Utilizes the linked queue class to create a priority queue based on elements entered
 */
public class Registrar {

	/**
	 * @param args not used command line arguments
	 */
	public static void main(String[] args) {
		
		LinkedQueue<Student> list=new LinkedQueue<Student>();
		boolean done=false; 
		Scanner in = new Scanner(System.in);
        System.out.println("Welcome to the Registrat");
		while (!done){
			System.out.println("\nChoices are");
		    System.out.println("1. Add Student to the queue");
		    System.out.println("2. Remove and print the first student");
		    System.out.println("3. Quit");
		    int choice = in.nextInt();
		    	System.out.println("\nYour choice: "+choice);
		    if (choice == 1){
		    	System.out.println("Student name: ");
		    	String name= in.next();
		    	System.out.println("Year: ");
		    	int year = in.nextInt();
		    	System.out.println("GPA: ");
		    	double gpa= in.nextDouble();
		    	Student s1= new Student(name,year,gpa);
		    	
		    	list.insert(s1);
		    	System.out.println(list.toList());
		    	}
		    else if (choice ==2) {
		    	System.out.println(list.dequeue()); //returns the first item in the priority queue
		    }
		    else if (choice ==3) done = true;
		    
		}
		in.close();
		
        

	}

}
