/**
 * $Id: ToComp.java,v 1.2 2014/10/01 03:01:43 mer8503 Exp $
 * 
 * $Log: ToComp.java,v $
 * Revision 1.2  2014/10/01 03:01:43  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/10/01 03:01:01  mer8503
 * *** empty log message ***
 *
 */

import java.util.Comparator; 

/**
 * 
 * @author Michael Rinos mer8503
 *
 */

public class ToComp implements Comparator<Stock> {
	/**
	 * compare method for stocks with the same name
	 */
	
	public int compare(Stock stock, Stock other) {
		return other.getValue()-stock.getValue();
		
	}	
}
