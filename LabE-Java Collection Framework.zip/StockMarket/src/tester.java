import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class tester {



	

	public static void main(String[] args) {
		
		Set<Stock> tree=new TreeSet<Stock>(new ToComp());
		Set<Stock> hashSet= new HashSet<Stock>();
		ArrayList<Stock> list=new ArrayList<Stock>();
		
		Stock s1 = new Stock("EBAY",10,1);
		Stock s2 = new Stock("YHOO",20,2);
		Stock s3 = new Stock("AAPL",30,4);
		
		String x="EBAY";
		String y="YHOO";
		String z="AMZN";
		
		double que=(double)(Math.random()*5);
		
		
		
		double newval=(500*que)/1;
		int val=(int) newval;
		
		String one="EBAY";
		String two="GOOG";
		String three="AAA";
		String four="BBB";
		System.out.println(one.compareTo(two));
		System.out.println(three.compareTo(four));

	}
}
