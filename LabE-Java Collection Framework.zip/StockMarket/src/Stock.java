/**
 * $Id: Stock.java,v 1.4 2014/10/01 03:01:43 mer8503 Exp $
 * 
 * $Log: Stock.java,v $
 * Revision 1.4  2014/10/01 03:01:43  mer8503
 * *** empty log message ***
 *
 * Revision 1.3  2014/10/01 03:01:16  mer8503
 * *** empty log message ***
 *
 * Revision 1.2  2014/10/01 03:01:01  mer8503
 * *** empty log message ***
 *
 */


/**
 * @author Michael Rinos mer8503
 *
 */
public class Stock{
	private String name;
	private int StockPrice;
	private int shares=0;
	/**
	 * default constructor
	 */
	public Stock(){
		this("Nothing",0);
	}
	
	/**
	 * overloaded constructor
	 */
	public Stock(String name,int price){
		this.name=name;
		this.StockPrice=price;
	}
	
	/**
	 * overloaded constructor 
	 */
	public Stock(String name,int price,int shares){
		this.name=name;
		this.StockPrice=price;
		this.shares=shares;
	}
	/**
	 * 
	 * @return price of stock
	 */
	public int getStockPrice() {
		return StockPrice;
	}
	/**
	 * 
	 * @param shares the amount of shares to add to the existing amount
	 */
	public void plusGets(int shares){
		shares+=shares;
	}
	/**
	 * 
	 * @param @param shares the amount of shares to subtract to the existing amount
	 */
	public void minusGets(int shares){
		this.shares-=shares;
	}
	/**
	 * 
	 * @param stockPrice the new price to set the stock to.
	 */
	public void setStockPrice(int stockPrice) {
		StockPrice = stockPrice;
	}
	/**
	 * @return the number of shares owned. 
	 */
	public int getShares() {
		return shares;
	} 
	/**
	 *  
	 * @return the total value of the stock 
	 */
	public int getValue(){
		return this.shares*this.StockPrice;
	}
	/**
	 * @return the name of the stock.
	 */
	public String getName(){
		return this.name;
	}
	/**
	 * the overided equals method.
	 */
	
	@Override
	public boolean equals(Object other){
		boolean result=false;
		if (other instanceof Stock){
			Stock s= (Stock) other;
			//System.out.println("STOCK");
			//System.out.println(this.name);
			//System.out.println(s.name);
			if (this.name.equals(s.name)){
				result=true;
			}
		}
		
		return result;
	}	
}
