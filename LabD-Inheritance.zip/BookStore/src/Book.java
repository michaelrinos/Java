/**
 * 
 * $Id: Book.java,v 1.2 2014/09/22 21:17:39 mer8503 Exp $
 * 
 * $Log: Book.java,v $
 * Revision 1.2  2014/09/22 21:17:39  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/21 01:52:29  mer8503
 * *** empty log message ***
 *
 * 
 */

/**
 * @author mer8503 Michael Rinos
 *
 */
public abstract class Book {
	private String title;
	private String author;
	private int cost;
	private Media media;
	
	/**
	 * default constructor 
	 * @param title (String) title of the book
	 * @param author (String) author of the book
	 * @param cost (int) cost of the book
	 */
	public Book(String title, String author, int cost){
		this(title,author,cost,null);
	}
	/**
	 * Overloaded constructor
	 * @param title (String) title of the book
	 * @param author (String) author of the book
	 * @param cost (int) cost of the book
	 * @param media (Media) which subclass of book it is
	 */
	public Book(String title,String author,int cost, Media media){
		this.title=title;
		this.author=author;
		this.cost=cost;
		this.media=media;
	}
	
	/**
	 * @return the books author
	 */
	public String getAuthor(){
		return this.author;
	}
	
	/**
	 * @return the book's cost converted into dollars and cents
	 */
	public double getCost(){
		double x=this.cost/100.0;
		return x;
	}
	
	/**
	 * gets the display string representation of the book's media
	 * @return the books media
	 */
	public String getMedia(){
		return media.toString();
	}
	
	/** 
	 * @return The book title enclosed in double quotes
	 */
	public String getTitle(){
		return this.title;
	}
	
	/**
	 * abstract is for sale function for all sub book classes
	 * @return True if this instance is for a final sale 
	 */
	public abstract boolean isForSale();
	
	/**
	 * The standard string representing prints the title on the first line, followed by the author on the second line,\
	 * and the book media on the third line. The second and subsequent lines are indented by a single TAB character.
	 *  Each line should be terminated with a period(.).
	 *  @return String representation of Book
	 */
	public String toString(){
		String string="";
		string+=this.title+"\n"+"\t";
		string+=this.author+"\n"+"\t";
		string+=this.media;	
		return string;
	}
	
}
