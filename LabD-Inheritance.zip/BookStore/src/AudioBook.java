/**
 * 
 * $Id: AudioBook.java,v 1.2 2014/09/22 21:17:40 mer8503 Exp $
 * 
 * $Log: AudioBook.java,v $
 * Revision 1.2  2014/09/22 21:17:40  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/21 01:52:30  mer8503
 * *** empty log message ***
 *
 * 
 */

/**
 * @author mer8503 Michael Rinos
 *
 */
public class AudioBook extends Book {
	private int numDiscs;
	private Media media;
	/**
	 * default constructor 
	 */
	public AudioBook(){
		this("None", "Nobody",0, 0);
	}
	/**
	 * Overloaded Constructor
	 * @param title (String) title of book
	 * @param author (String) author of the book
	 * @param cost (int) cost of the book
	 * @param numDiscs (int) indicating the number of discs for the book
	 */
	public AudioBook(String title,String author,int cost,int numDiscs){
		super(title,author,cost,Media.Audio);
		this.numDiscs=numDiscs;
	}

	/**
	 * The isForSale implementation depends on the book's media. Some kinds of books are offered only for rent, not for sale.
	 * @return true if this instance is for a final sale (it is)
	 */
	public boolean isForSale() {
		return false;
	}
	/**
	 * The toString represents an AudioBook by adding ": {n} disks." to the standard string representation of a Book. 
	 * The {n} in this case is the number of discs.
	 */
	public String toString(){
		String string="";
		String[] sLines=super.toString().split("\n");
		string+=sLines[0]+"."+"\n";
		string+=sLines[1]+"."+"\n";
		string+=sLines[2]+": "+this.numDiscs+" disks.";
		return string;
	}
	public String getMedia(){
		return Media.Audio.toString();
	}
}
