/**
 * 
 * $Id: PaperBack.java,v 1.2 2014/09/22 21:17:40 mer8503 Exp $
 * 
 * $Log: PaperBack.java,v $
 * Revision 1.2  2014/09/22 21:17:40  mer8503
 * *** empty log message ***
 *
 * Revision 1.1  2014/09/21 01:52:30  mer8503
 * *** empty log message ***
 *
 */


/**
 * @author mer8503 Michael Rinos
 *
 */
public class PaperBack extends Book{
	/**
	 * default constructor 
	 */
	public PaperBack(){
		this("None","Nobody",0);
	}
	/**
	 * Overloaded Constructor
	 * @param title (String) title of book
	 * @param author (String) author of the book
	 * @param cost (int) cost of the book
	 */
	public PaperBack(String title,String author,int Cost){
		super(title,author,Cost,Media.Paperback);
		
	}
	/**
	 * The isForSale implementation depends on the book's media. Some kinds of books are offered only for rent, not for sale.
	 * @return true if this instance is for a final sale (it is)
	 */
	public boolean isForSale(){
		return true;
	}
	/**
	 * toString adds a trailing period at the end of the returned text from the abstract class book
	 * @return abstract class to string plus a period at the end (talk about a useless function)
	 */
	public String toString(){
		String string="";
		String[] sLines=super.toString().split("\n");
		string+=sLines[0]+"."+"\n";
		string+=sLines[1]+"."+"\n";
		string+=sLines[2]+".";
		
		return string;
	}
}
